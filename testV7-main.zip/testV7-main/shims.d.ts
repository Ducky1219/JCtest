// Auto-generated. Do not edit.



    //% color=50 weight=80
    //% icon="\uf1eb"
declare namespace i2c {
}

declare namespace Bit_IR {
}
// Auto-generated. Do not edit. Really.
